create procedure im_proc_list_name()
    language plpgsql
as
$$
declare
    r record;
begin
    for r in select name from FOREST
        loop
            raise notice '%', r.name;
        end loop;
end
$$;

alter procedure im_proc_list_name() owner to postgres;

