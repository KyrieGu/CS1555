create procedure ex_proc_list_name()
    language plpgsql
as
$$
DECLARE
    r record;
    cr cursor
        for select name
            from FOREST;
begin
    open cr;
    loop
        fetch cr into r;
        exit when not found;
        raise notice '%', r.name;
    end loop;
    close cr;
end
$$;

alter procedure ex_proc_list_name() owner to postgres;

