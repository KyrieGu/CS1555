create function pro_update_last_read() returns trigger
    language plpgsql
as
$$
begin
        update SENSOR
        set Last_Read = new.Report_Time
        where Sensor_Id = new.Sensor_Id;
        return new;
    end;
$$;

alter function pro_update_last_read() owner to postgres;

