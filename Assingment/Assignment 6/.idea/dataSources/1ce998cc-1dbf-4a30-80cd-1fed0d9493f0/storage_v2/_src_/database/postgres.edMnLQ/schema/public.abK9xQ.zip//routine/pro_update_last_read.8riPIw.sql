create procedure pro_update_last_read(input_sensor_id integer, read_time timestamp without time zone)
    language plpgsql
as
$$
begin
    update SENSOR
    set Last_Read = read_time
    where Sensor_Id = input_sensor_id;
end;
$$;

alter procedure pro_update_last_read(integer, timestamp) owner to postgres;

