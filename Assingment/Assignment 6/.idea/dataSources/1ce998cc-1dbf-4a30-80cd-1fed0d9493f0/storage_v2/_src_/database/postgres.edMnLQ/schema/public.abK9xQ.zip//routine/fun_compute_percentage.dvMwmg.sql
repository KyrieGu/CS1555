create function fun_compute_percentage(input_forest_no character, area_covered double precision) returns double precision
    language plpgsql
as
$$
declare
    result float := .0;
begin
    select area_covered / area
    into result
    from Forest
    where forest_no = input_forest_no;
    if result >= 1 then
        return 1.0;
    end if;
    return result;
end;
$$;

alter function fun_compute_percentage(char, double precision) owner to postgres;

