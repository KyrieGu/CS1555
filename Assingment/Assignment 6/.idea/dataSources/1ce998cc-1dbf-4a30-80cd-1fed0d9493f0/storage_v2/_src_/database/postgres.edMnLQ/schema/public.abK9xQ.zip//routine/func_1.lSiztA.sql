create function func_1() returns trigger
    language plpgsql
as
$$
begin
        update COVERAGE
        set Percentage = fun_Compute_Percentage(Forest_No,Area)
        where Forest_No = new.forest_no;
        return new;
    end;
$$;

alter function func_1() owner to postgres;

