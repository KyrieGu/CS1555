create function func_emergency() returns trigger
    language plpgsql
as
$$
begin
        insert into Emergency values (new.sensor_id, new.report_time);
        return new;
    end;
$$;

alter function func_emergency() owner to postgres;

